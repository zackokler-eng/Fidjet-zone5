FIDGET ZONE — CRATE ANIMATION + FIDGET REWARDS

Includes animated crate opening and a reward popup when you use fidgets. Popping a new bubble earns +5 XP and +3 coins. Button mash, boop, joystick and switches award coins and XP; sliders award small rewards with a short cooldown.

Deploy this folder containing index.html with Netlify. To keep your current URL, upload this folder through the existing Netlify site’s Deploys page. A new Netlify Drop site may receive a different URL.

Progress is stored in browser localStorage on this device. Do not clear site data if you want to keep local progress. These are pretend game coins, not real money.
